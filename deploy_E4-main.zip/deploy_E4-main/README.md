# Django server
1. Build images - `docker-compose build`
2. Start services - `docker-compose up -d`
3. Open link - http://localhost:8080/